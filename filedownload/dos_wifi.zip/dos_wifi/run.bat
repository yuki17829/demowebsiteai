@echo off
pip install scapy
pip install aiohttp
pip install aiohttp aiofiles requests flask flask-cors pywebview pyautogui psutil pillow
echo HieuNguyxn...
start /min "Terminal 1" cmd /k python dos.py
timeout /t 1 >nul
start /min "Terminal 2" cmd /k python dos.py
timeout /t 1 >nul
start /min "Terminal 3" cmd /k python dos.py
timeout /t 1 >nul
start /min "Terminal 4" cmd /k python dos.py
timeout /t 1 >nul
start /min "Terminal 5" cmd /k python dos.py
timeout /t 1 >nul
start /min "Terminal 6" cmd /k python dos.py
timeout /t 1 >nul
start /min "Terminal 7" cmd /k python dos.py
timeout /t 1 >nul
start /min "Terminal 8" cmd /k python dos.py
timeout /t 1 >nul
start /min "Terminal 9" cmd /k python dos.py
timeout /t 1 >nul
start /min "Terminal 10" cmd /k python dos.py
pause